# HealthVideo Studio MVP 0.1

## Mục tiêu
Web app MVP cho quy trình sản xuất video hàng loạt về sức khỏe cá nhân hóa và affiliate:
- Nhập brief một lần, tạo 10 concept mẫu.
- Sửa tiêu đề, hook, kịch bản, prompt video, caption và ghi chú duyệt.
- Trạng thái: Chờ duyệt / Cần sửa / Đã duyệt / Đã xuất.
- Xuất dữ liệu JSON và CSV.
- Lưu cấu hình nhận diện kênh trên trình duyệt bằng localStorage.

## Chạy thử
1. Giải nén file ZIP.
2. Mở `index.html` bằng Chrome, Edge hoặc trình duyệt hiện đại.
3. Vào **Tạo lô video**, nhập chủ đề và nhấn **Tạo 10 concept**.
4. Vào **Kho video**, mở từng video để chỉnh sửa/duyệt.
5. Xuất CSV/JSON để lưu trữ hoặc chuyển sang quy trình sản xuất.

Không cần cài đặt hoặc API key để chạy demo.

## Giới hạn quan trọng
- Bản hiện tại là frontend demo chạy tại trình duyệt; nội dung được tạo bằng mẫu/logic cố định, chưa gọi LLM.
- Chưa tạo file video MP4, chưa tạo giọng đọc, chưa kết nối Veo/Google Flow hay tự đăng mạng xã hội.
- Dữ liệu chỉ nằm trong localStorage trên trình duyệt/thiết bị hiện tại; xóa dữ liệu trình duyệt có thể làm mất dữ liệu. Không lưu dữ liệu sức khỏe cá nhân nhạy cảm.
- Đây là công cụ hỗ trợ nội dung, không thay thế đánh giá y khoa/pháp lý. Tất cả tuyên bố sức khỏe và quảng cáo cần được kiểm tra nguồn trước khi xuất bản.

## Kiến trúc đề xuất cho bản production
Frontend: Next.js/React + TypeScript.
Backend: API routes/Node.js.
Database & auth: Supabase (Postgres/Auth/Storage) hoặc tương đương.
LLM: OpenAI API hoặc nhà cung cấp khác, gọi từ backend.
Tạo ảnh/video: chọn nhà cung cấp có API được cấp quyền và phù hợp chi phí; nếu dùng Google Flow/Veo, cần xác minh khả năng API/điều khoản hiện hành, không mặc định giao diện Flow có API tự động.
Voice: dịch vụ TTS có tiếng Việt và quyền sử dụng thương mại.
Render: FFmpeg trong worker/container; lưu MP4 vào object storage.
Queue: job queue để xử lý theo lô, retry và theo dõi trạng thái.
Human approval: chỉ cho phép chuyển sang xuất/đăng khi video được người dùng duyệt.

## Các khóa/dịch vụ cần có khi tích hợp
- LLM API key và tài khoản thanh toán/giới hạn sử dụng.
- Nhà cung cấp video/image API và quyền truy cập phù hợp.
- TTS API key nếu dùng giọng đọc tự động.
- Hosting/backend, database, storage nếu cần dùng nhiều thiết bị.
- API mạng xã hội nếu muốn tự đăng; quyền truy cập và xét duyệt ứng dụng tùy nền tảng.

Không đặt API key trong HTML hoặc trình duyệt. Lưu secret ở biến môi trường phía server.
